package com.ljj.controller;

import com.ljj.dao.NoticeRepository;
import com.ljj.entity.Notice;
import com.ljj.util.CommonResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.annotation.Resource;

public class NoticeController {
    @Resource
    private NoticeRepository noticeRepository;

    @PostMapping
    public CommonResult save(Notice notice){

        return null;
    }

    @GetMapping
    public Object selectAll(){

        return null;
    }

    @GetMapping
    public Object selectOne(){

        return null;
    }
}
