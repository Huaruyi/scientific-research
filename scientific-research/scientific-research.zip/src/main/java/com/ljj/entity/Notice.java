package com.ljj.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "notice")
public class Notice implements Serializable {
    /**
     * ID
     */
    @Id
    @OrderBy
    @GeneratedValue
    private Long id;
    /**
     * 标题
     */
    private String title;
    /**
     * 内容
     */
    private String content;
    /**
     * 发布时间(时间戳）
     */
    private Long time;
}
