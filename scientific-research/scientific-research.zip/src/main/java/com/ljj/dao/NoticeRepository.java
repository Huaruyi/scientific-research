package com.ljj.dao;

import com.ljj.entity.Notice;
import com.ljj.entity.Research;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Hua Ruyi
 * @version 1.0
 * @date 2020/9/25 16:08
 */
public interface NoticeRepository extends JpaRepository<Notice,Long> {
}
