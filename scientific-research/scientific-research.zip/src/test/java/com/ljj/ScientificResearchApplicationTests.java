package com.ljj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScientificResearchApplicationTests {

    @Test
    void contextLoads() {
    }

}
